// src/navigation/navigationTypes.ts
export type RootStackParamList = {
    SelectSport: undefined;
    SelectTime: { sport: string };
  };
  